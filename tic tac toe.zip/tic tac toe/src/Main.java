import java.util.*;

public class Main {
    static ArrayList<Integer> PlayerPositions = new ArrayList<Integer>();
    static ArrayList<Integer> cpuPositions = new ArrayList<Integer>();
    public static void main(String[] args) {
        char[][] gameBoard = {{' ', '|', ' ', '|', ' '},
                {'-', '+', '-', '+', '-'},
                {' ', '|', ' ', '|', ' '},
                {'-', '+', '-', '+', '-'},
                {' ', '|', ' ', '|', ' '}};
        printGameboard(gameBoard);

        int PlayerPos;
        while (true) {

            Scanner scan = new Scanner(System.in);
            System.out.println("wprowadź położenie X od 1-9 ");
            PlayerPos = scan.nextInt();
            while (PlayerPositions.contains(PlayerPos) || cpuPositions.contains(PlayerPos)) {
                System.out.println("położenie zajętę! wporwadź nowe położenie");
                PlayerPos = scan.nextInt();
            }


            Setpiece(gameBoard, PlayerPos, "player");

            Random rand = new Random();
            int cpuPos = rand.nextInt(9) + 1;
            while (PlayerPositions.contains(cpuPos) || cpuPositions.contains(cpuPos)) {
                cpuPos = rand.nextInt(9) + 1;
            }
            Setpiece(gameBoard, cpuPos, "cpu");
            printGameboard(gameBoard);
            String result = Winnercheck();
            System.out.println(result);
        }
    }

    //wypisanie tablicy do gry
    public static void printGameboard(char[][] gameBoard) {
        for (char[] row : gameBoard) {
            for (char c : row) {
                System.out.print(c);
            }
            System.out.println();
        }
    }

    //stawianie symbolu na tablicy oraz wybieranie symbolu zależności czy to komputer czy gracz

    public static void Setpiece(char[][] gameBoard, int position, String user) {
        char symbol = ' ';
        if(user.equals("player")) {
            symbol = 'X';
            PlayerPositions.add(position);
        } else if (user.equals("cpu")) {
            symbol = 'O';
             cpuPositions.add(position);
            
        }

        switch (position) {
            case 1:
                gameBoard[0][0] = symbol;
                break;
            case 2:
                gameBoard[0][2] = symbol;
                break;
            case 3:
                gameBoard[0][4] = symbol;
                break;
            case 4:
                gameBoard[2][0] = symbol;
                break;
            case 5:
                gameBoard[2][2] = symbol;
                break;
            case 6:
                gameBoard[2][4] = symbol;
                break;
            case 7:
                gameBoard[4][0] = symbol;
                break;
            case 8:
                gameBoard[4][2] = symbol;
                break;
            case 9:
                gameBoard[4][4] = symbol;
                break;
            default:
                break;
        }

    }
    //sprawdzanie czy ktoś wygrał patrząc na każdy możliwy sposób wygrania i sprawdzania czy był osiągnięty
    public static String Winnercheck() {
        List TopRow = Arrays.asList(1, 2, 3);
        List MidRow = Arrays.asList(4, 5, 6);
        List BotRow = Arrays.asList(7, 8, 9);

        List LeftCol = Arrays.asList(1, 4, 7);
        List MidCol = Arrays.asList(2, 5, 8);
        List RightCol = Arrays.asList(3, 6, 9);

        List cross1 = Arrays.asList(1, 5, 9);
        List cross2 = Arrays.asList(3, 5, 7);

        List<List> winningConditions = new ArrayList<List>();
        winningConditions.add (TopRow);
        winningConditions.add (MidRow);
        winningConditions.add (BotRow);
        winningConditions.add (LeftCol);
        winningConditions.add (MidCol);
        winningConditions.add (RightCol);
        winningConditions.add (cross1);
        winningConditions.add (cross2);

        for (List l : winningConditions) {
            if(PlayerPositions.containsAll(l)) {
                return " YIPPIE!!!! wygrałeśśś!!!!1!!!1";
            }else if(cpuPositions.containsAll(l)) {
                return "Przegałeś :(((((";
            }else if(PlayerPositions.size()+ cpuPositions.size() ==9) {
                return "Tie";}
                }
        return "";
            }

        }